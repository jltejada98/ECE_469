#include "usertraps.h"

void main (int argc, char *argv[])
{
  run_os_tests();
}
