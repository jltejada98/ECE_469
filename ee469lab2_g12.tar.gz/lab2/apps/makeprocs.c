//
// Created by Jose Luis Tejada on 11/2/20.
//


#include "lab2-api.h"
#include "usertraps.h"
#include "misc.h"

#include "spawn.h"

void main (int argc, char *argv[]){
    int numprocs = 0;               // Used to store number of processes to create
    int i;                          // Loop index variable

    Printf("Hello\n")





}
