#ifndef __USERPROG__
#define __USERPROG__

typedef struct missile_code {
  int numprocs;
  char really_important_char;
} missile_code;

#define PRODUCER_FILENAME "spawn_me.dlx.obj"

#define CONSUMER_FILENAME "spawn_me.dlx.obj"

#endif
