#ifndef __FILE_TEST_H__
#define __FILE_TEST_H__

#ifndef NULL
#define NULL (void *)0x0
#endif

#endif
