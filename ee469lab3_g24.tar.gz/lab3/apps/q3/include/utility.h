#define PROC_FILENAME "nothing_proc.dlx.obj"

