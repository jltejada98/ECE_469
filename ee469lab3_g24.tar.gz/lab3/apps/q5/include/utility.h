#define SLEEP_PROC_NAME "wait_proc.dlx.obj"

